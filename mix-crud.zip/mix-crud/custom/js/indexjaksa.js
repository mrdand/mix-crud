// global the manage memeber table 
var manageJaksaTable;

$(document).ready(function() {
	manageJaksaTable = $("#manageJaksaTable").DataTable({
		"ajax": "jaksa_action/retrieve.php",
		"order": []
	});

	$("#addJaksaModalBtn").on('click', function() {
		// reset the form 
		$("#createJaksaForm")[0].reset();
		// remove the error 
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".messages").html("");

		// submit form
		$("#createJaksaForm").unbind('submit').bind('submit', function() {

			$(".text-danger").remove();

			var form = $(this);

			// validation
			var nip = $("#nip").val();
			var nama = $("#nama").val();
			var nrp = $("#nrp").val();

			if(nip == "") {
				$("#nip").closest('.form-group').addClass('has-error');
				$("#nip").after('<p class="text-danger">Harus diisi!</p>');
			} else {
				$("#nip").closest('.form-group').removeClass('has-error');
				$("#nip").closest('.form-group').addClass('has-success');				
			}

			if(nama == "") {
				$("#nama").closest('.form-group').addClass('has-error');
				$("#nama").after('<p class="text-danger">Harus diisi!</p>');
			} else {
				$("#nama").closest('.form-group').removeClass('has-error');
				$("#nama").closest('.form-group').addClass('has-success');				
			}

			if(nrp == "") {
				$("#nrp").closest('.form-group').addClass('has-error');
				$("#nrp").after('<p class="text-danger">Harus diisi!</p>');
			} else {
				$("#nrp").closest('.form-group').removeClass('has-error');
				$("#nrp").closest('.form-group').addClass('has-success');				
			}

			if(nip && nama && nrp) {
				//submi the form to server
				$.ajax({
					url : form.attr('action'),
					type : form.attr('method'),
					data : form.serialize(),
					dataType : 'json',
					success:function(response) {

						// remove the error 
						$(".form-group").removeClass('has-error').removeClass('has-success');

						if(response.success == true) {
							$(".messages").html('<div class="alert alert-success alert-dismissible" role="alert">'+
							  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
							  '<strong> <span class="glyphicon glyphicon-ok-sign"></span> </strong>'+response.messages+
							'</div>');

							// reset the form
							$("#createJaksaForm")[0].reset();		

							// reload the datatables
							manageJaksaTable.ajax.reload(null, false);
							// this function is built in function of datatables;

						} else {
							$(".messages").html('<div class="alert alert-warning alert-dismissible" role="alert">'+
							  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
							  '<strong> <span class="glyphicon glyphicon-exclamation-sign"></span> </strong>'+response.messages+
							'</div>');
						}  // /else
					} // success  
				}); // ajax subit 				
			} /// if


			return false;
		}); // /submit form for create member
	}); // /add modal

});

function removeJaksa(id = null) {
	if(id) {
		// click on remove button
		$("#removeBtn").unbind('click').bind('click', function() {
			$.ajax({
				url: 'jaksa_action/remove.php',
				type: 'post',
				data: {id : id},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {						
						$(".removeMessages").html('<div class="alert alert-success alert-dismissible" role="alert">'+
							  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
							  '<strong> <span class="glyphicon glyphicon-ok-sign"></span> </strong>'+response.messages+
							'</div>');

						// refresh the table
						manageJaksaTable.ajax.reload(null, false);

						// close the modal
						$("#removeJaksaModal").modal('hide');

					} else {
						$(".removeMessages").html('<div class="alert alert-warning alert-dismissible" role="alert">'+
							  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
							  '<strong> <span class="glyphicon glyphicon-exclamation-sign"></span> </strong>'+response.messages+
							'</div>');
					}
				}
			});
		}); // click remove btn
	} else {
		alert('Error: Refresh the page again');
	}
}

function editJaksa(id = null) {
	if(id) {

		// remove the error 
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$(".text-danger").remove();
		// empty the message div
		$(".edit-messages").html("");

		// remove the id
		$("#id").remove();

		// fetch the member data
		$.ajax({
			url: 'jaksa_action/getSelectedJaksa.php',
			type: 'post',
			data: {id : id},
			dataType: 'json',
			success:function(response) {
				$("#editNip").val(response.nip);

				$("#editNama").val(response.nama);

				$("#editNrp").val(response.nrp);

				$("#editKarpeg").val(response.karpeg);

				$("#editTtl").val(response.ttl);

				$("#editAgama").val(response.agama);

				$("#editJk").val(response.jk);

				$("#editStatus_nikah").val(response.status_nikah);

				$("#editJum_anak").val(response.jum_anak);

				$("#editAlamat").val(response.alamat);

				$("#editHp").val(response.hp);

				$("#editPendidikan").val(response.pendidikan);

				$("#editGolru").val(response.golru);

				$("#editPangkat").val(response.pangkat);

				$("#editStruktural").val(response.struktural);

				$("#editFungsional").val(response.fungsional);

				$("#editTmt_jaksa").val(response.tmt_jaksa);

				$("#editPassword").val(response.password);

				$("#editFoto").val(response.foto);

				// mmeber id 
				$(".editJaksaModal").append('<input type="hidden" name="id" id="id" value="'+response.id+'"/>');

				// here update the member data
				$("#updateJaksaForm").unbind('submit').bind('submit', function() {
					// remove error messages
					$(".text-danger").remove();

					var form = $(this);

					// validation
					var editNip = $("#editNip").val();
					var editNama = $("#editNama").val();
					var editNrp = $("#editNrp").val();

					if(editNip == "") {
						$("#editNip").closest('.form-group').addClass('has-error');
						$("#editNip").after('<p class="text-danger">Harus diisi!</p>');
					} else {
						$("#editNip").closest('.form-group').removeClass('has-error');
						$("#editNip").closest('.form-group').addClass('has-success');				
					}

					if(editNama == "") {
						$("#editNama").closest('.form-group').addClass('has-error');
						$("#editNama").after('<p class="text-danger">Harus diisi!</p>');
					} else {
						$("#editNama").closest('.form-group').removeClass('has-error');
						$("#editNama").closest('.form-group').addClass('has-success');				
					}

					if(editNrp == "") {
						$("#editNrp").closest('.form-group').addClass('has-error');
						$("#editNrp").after('<p class="text-danger">Harus diisi!</p>');
					} else {
						$("#editNrp").closest('.form-group').removeClass('has-error');
						$("#editNrp").closest('.form-group').addClass('has-success');				
					}

					if(editNip && editNama && editNrp) {
						$.ajax({
							url: form.attr('action'),
							type: form.attr('method'),
							data: form.serialize(),
							dataType: 'json',
							success:function(response) {
								if(response.success == true) {
									$(".edit-messages").html('<div class="alert alert-success alert-dismissible" role="alert">'+
									  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
									  '<strong> <span class="glyphicon glyphicon-ok-sign"></span> </strong>'+response.messages+
									'</div>');

									// reload the datatables
									manageJaksaTable.ajax.reload(null, false);
									// this function is built in function of datatables;

									// remove the error 
									$(".form-group").removeClass('has-success').removeClass('has-error');
									$(".text-danger").remove();
								} else {
									$(".edit-messages").html('<div class="alert alert-warning alert-dismissible" role="alert">'+
									  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
									  '<strong> <span class="glyphicon glyphicon-exclamation-sign"></span> </strong>'+response.messages+
									'</div>')
								}
							} // /success
						}); // /ajax
					} // /if

					return false;
				});

			} // /success
		}); // /fetch selected member info

	} else {
		alert("Error : Refresh the page again");
	}
}