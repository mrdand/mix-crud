<?php 

require_once 'db_connect.php';

//if form is submitted
if($_POST) {	

	$validator = array('success' => false, 'messages' => array());

	$id = $_POST['id'];
	$nip = $_POST['editNip'];
	$nama = $_POST['editNama'];
	$nrp = $_POST['editNrp'];
	$karpeg = $_POST['editKarpeg'];
	$ttl = $_POST['editTtl'];
	$agama = $_POST['editAgama'];
	$jk = $_POST['editJk'];
	$status_nikah = $_POST['editStatus_nikah'];
	$jum_anak = $_POST['editJum_anak'];
	$alamat = $_POST['editAlamat'];
	$hp = $_POST['editHp'];
	$pendidikan = $_POST['editPendidikan'];
	$golru = $_POST['editGolru'];
	$pangkat = $_POST['editPangkat'];
	$struktural = $_POST['editStruktural'];
	$fungsional = $_POST['editFungsional'];
	$tmt_jaksa = $_POST['editTmt_jaksa'];
	$password = $_POST['editPassword'];
	$foto = $_POST['editFoto'];

	$sql = "UPDATE tb_jaksa SET nip = '$nip', nama = '$nama', nrp = '$nrp', karpeg = '$karpeg', ttl = '$ttl', agama = '$agama', jk = '$jk', status_nikah = '$status_nikah', jum_anak = '$jum_anak', alamat = '$alamat', hp = '$hp', pendidikan = '$pendidikan', golru = '$golru', pangkat = '$pangkat', struktural = '$struktural', fungsional = '$fungsional', tmt_jaksa = '$tmt_jaksa', password  = '$password', foto = '$foto' WHERE id = $id";
	$query = $connect->query($sql);

	if($query === TRUE) {			
		$validator['success'] = true;
		$validator['messages'] = "Successfully Added";		
	} else {		
		$validator['success'] = false;
		$validator['messages'] = "Error while adding the Jaksa information";
	}

	// close the database connection
	$connect->close();

	echo json_encode($validator);

}