<?php 

require_once 'db_connect.php';

$output = array('success' => false, 'messages' => array());

$jaksaId = $_POST['id'];

$sql = "DELETE FROM tb_jaksa WHERE id = {$jaksaId}";
$query = $connect->query($sql);
if($query === TRUE) {
	$output['success'] = true;
	$output['messages'] = 'Successfully removed';
} else {
	$output['success'] = false;
	$output['messages'] = 'Error while removing the Jaksa information';
}

// close database connection
$connect->close();

echo json_encode($output);