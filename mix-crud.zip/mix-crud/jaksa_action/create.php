<?php 

require_once 'db_connect.php';

//if form is submitted
if($_POST) {	

	$validator = array('success' => false, 'messages' => array());

	$nip = $_POST['nip'];
	$nama = $_POST['nama'];
	$nrp = $_POST['nrp'];
	$karpeg = $_POST['karpeg'];
	$ttl = $_POST['ttl'];
	$agama = $_POST['agama'];
	$jk = $_POST['jk'];
	$status_nikah = $_POST['status_nikah'];
	$jum_anak = $_POST['jum_anak'];
	$alamat = $_POST['alamat'];
	$hp = $_POST['hp'];
	$pendidikan = $_POST['pendidikan'];
	$golru = $_POST['golru'];
	$pangkat = $_POST['pangkat'];
	$struktural = $_POST['struktural'];
	$fungsional = $_POST['fungsional'];
	$tmt_jaksa = $_POST['tmt_jaksa'];
	$password = $_POST['password'];
	$foto = $_POST['foto'];

	$sql = "INSERT INTO tb_jaksa (nip, nama, nrp, karpeg, ttl, agama, jk, status_nikah, jum_anak, alamat, hp, pendidikan, golru, pangkat, struktural, fungsional, tmt_jaksa, password, foto) VALUES ('$nip', '$nama', '$nrp', '$karpeg', '$ttl', '$agama', '$jk', '$status_nikah', '$jum_anak', '$alamat', '$hp', '$pendidikan','$golru', '$pangkat', '$struktural', '$fungsional', '$tmt_jaksa', '$password', '$foto' )";
	$query = $connect->query($sql);

	if($query === TRUE) {			
		$validator['success'] = true;
		$validator['messages'] = "Successfully Added";		
	} else {		
		$validator['success'] = false;
		$validator['messages'] = "Error while adding the Jaksa information";
	}

	// close the database connection
	$connect->close();

	echo json_encode($validator);

}