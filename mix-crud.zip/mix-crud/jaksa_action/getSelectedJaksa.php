<?php 

require_once 'db_connect.php';

$jaksaId = $_POST['id'];

$sql = "SELECT * FROM tb_jaksa WHERE id = $jaksaId";
$query = $connect->query($sql);
$result = $query->fetch_assoc();

$connect->close();

echo json_encode($result);

