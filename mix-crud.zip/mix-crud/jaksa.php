<!DOCTYPE html>
<html>
<head>
	<title>Data</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>

  <link rel="stylesheet" type="text/css" href="assests/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="assests/css/animate.css">
  <link rel="stylesheet" type="text/css" href="assests/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="assests/css/bootstrap-select.min.css">
  <link rel="stylesheet" type="text/css" href="assests/css/awesome-bootstrap-checkbox.css">
  <link rel="stylesheet" type="text/css" href="assests/css/select2.css">
  <link rel="stylesheet" type="text/css" href="assests/css/style.css">
  <link rel="stylesheet" type="text/css" href="assests/css/theme.css">

	<!-- bootstrap css -->
	<!-- <link rel="stylesheet" type="text/css" href="assests/bootstrap/css/bootstrap.min.css"> -->
	<!-- datatables css -->
	<link rel="stylesheet" type="text/css" href="assests/datatables/datatables.min.css">

</head>
<body class="flat-blue sidebar-collapse">

	<div class="sidebar">
      <div class="menu-control toggle-sidebar">
          <a class="navbar-brand" href="#"><i class="fa fa-bar-chart"></i> CRUD </a>
          <i class="fa fa-bars navicon"></i>
      </div>
      <ul class="menu">
          <li class="submenu">
              <a href="index.php">
                  <div>
                      <i class="menu-icon fa fa-th-large"></i>
                      <span class="menu-title">Dashboard</span>
                  </div>
              </a>
          </li>
          <li class="submenu">
              <a href="jaksa.php" class="active">
                  <div>
                      <i class="menu-icon fa fa-user"></i>
                      <span class="menu-title">Data </span>
                  </div>
              </a>
          </li>
  </div>
    <div class="content-container wrap">
        <nav class="navbar navbar-default">
            <div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"><i class="fa fa-bar-chart"></i> CRUD</a>
                    </div>
                    <ul class="nav navbar-nav navbar-right">

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Admin <span class="caret"></span></a>
                            <ul class="dropdown-menu user-info">
                                <li class="dropdown-title-bar">
                                    <img src="assests/images/profile.jpg" class="profile-img">
                                </li>
                                <li>
                                    <div class="navbar-login">
                                        <h4 class="user-name">Admin</h4>
                                        <p>admin@admin.com</p>
                                        <div class="btn-group margin-bottom-2x" role="group">
                                            <button type="button" class="btn btn-default"><i class="fa fa-user"></i> Profile</button>
                                            <button type="button" class="btn btn-default"><i class="fa fa-sign-out"></i> Logout</button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>

	<div class="container-fluid">
            <div class="row">
                <div class="col-xs-12">
                    <span class="page-title green"><h2>Jaksa</h2></span>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">

                    <ol class="breadcrumb">
                        <li><a href="#">Home</a>
                        </li>
                        <li class="active">Data</a>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <span class="page-title"><h4>Data</h4></span>
                </div>
            </div>

				<div class="removeMessages"></div>

				<button class="btn btn-primary pull pull-right" data-toggle="modal" data-target="#addJaksa" id="addJaksaModalBtn">
					<span class="fa fa-plus"></span>	Add
				</button>

				<div class="row">
	        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	            <div class="content-block">
	                <div class="block-title">Data</div>
	                <div class="block-content">

				<table class="table table-striped" id="manageJaksaTable">
					<thead>
						<tr>
							<th>No</th>
							<th>NIP</th>
              <th>Nama</th>
              <th>TTL</th>
              <th>Golongan</th>
              <th>Pangkat</th>
              <th>Struktural</th>
              <th>Fungsional</th>
              <th>Opsi</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</div>
</div>

	<!-- add modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="addJaksa">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><span class="glyphicon glyphicon-plus-sign"></span>	Tambah Data Jaksa</h4>
	      </div>

	      <form class="form-horizontal" action="jaksa_action/create.php" method="POST" id="createJaksaForm">

	      <div class="modal-body">
	      	<div class="messages"></div>

	      <div class="form-group">
			    <label for="nip" class="col-sm-3 control-label">NIP</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="nip" name="nip" placeholder="NIP">
			    </div>
			  </div>

			  <div class="form-group"> <!--/here teh addclass has-error will appear -->
			    <label for="nama" class="col-sm-3 control-label">Nama</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama">
				<!-- here the text will apper  -->
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="nrp" class="col-sm-3 control-label">NRP</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="nrp" name="nrp" placeholder="NRP">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="karpeg" class="col-sm-3 control-label">Karpeg</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="karpeg" name="karpeg" placeholder="Karpeg">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="ttl" class="col-sm-3 control-label">TTL</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="ttl" name="ttl" placeholder="TTL">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="agama" class="col-sm-3 control-label">Agama</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="agama" name="agama" placeholder="Agama">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="jk" class="col-sm-3 control-label">Jenis Kelamin</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="jk" name="jk" placeholder="Jenis Kelamin">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="status_nikah" class="col-sm-3 control-label">Status Nikah</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="status_nikah" name="status_nikah" placeholder="Status Nikah">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="jum_anak" class="col-sm-3 control-label">Jumlah Anak</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="jum_anak" name="jum_anak" placeholder="Jumlah Anak">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="alamat" class="col-sm-3 control-label">Alamat</label>
			    <div class="col-sm-9">
			    	<textarea class="form-control" id="alamat" name="alamat" rows="3" placeholder="Alamat"></textarea>
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="hp" class="col-sm-3 control-label">No. HP</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="hp" name="hp" placeholder="Nomor Handphone">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="pendidikan" class="col-sm-3 control-label">Pendidikan</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="pendidikan" name="pendidikan" placeholder="Pendidikan">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="golru" class="col-sm-3 control-label">Golongan</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="golru" name="golru" placeholder="Golongan">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="pangkat" class="col-sm-3 control-label">Pangkat</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="pangkat" name="pangkat" placeholder="Pangkat">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="struktural" class="col-sm-3 control-label">Struktural</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="struktural" name="struktural" placeholder="Struktural">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="fungsional" class="col-sm-3 control-label">Fungsional</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="fungsional" name="fungsional" placeholder="Fungsional">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="tmt_jaksa" class="col-sm-3 control-label">Tamat Jaksa</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="tmt_jaksa" name="tmt_jaksa" placeholder="Tamat Jaksa">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="password" class="col-sm-3 control-label">Password</label>
			    <div class="col-sm-9">
			      <textarea class="form-control" id="password" name="password" rows="3" placeholder="Password"></textarea>
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="foto" class="col-sm-3 control-label">Foto</label>
			    <div class="col-sm-9">
			    	<textarea class="form-control" id="foto" name="foto" rows="3" placeholder="Foto"></textarea>
			    </div>
			  </div>

<!-- 			  <div class="form-group">
			    <label for="active" class="col-sm-2 control-label">Active</label>
			    <div class="col-sm-10">
			      <select class="form-control" name="active" id="active">
			      	<option value="">~~SELECT~~</option>
			      	<option value="1">Activate</option>
			      	<option value="2">Deactivate</option>
			      </select>
			    </div>
			  </div>			 	 -->

	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Save changes</button>
	      </div>
	      </form>
	    </div><!-- /.modal-content -->
	  </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- /add modal -->

	<!-- remove modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="removeJaksaModal">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><span class="glyphicon glyphicon-trash"></span> Hapus Data Jaksa</h4>
	      </div>
	      <div class="modal-body">
	        <p>Anda yakin ingin hapus data ini ?</p>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="button" class="btn btn-primary" id="removeBtn">Save changes</button>
	      </div>
	    </div><!-- /.modal-content -->
	  </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- /remove modal -->

	<!-- edit modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="editJaksaModal">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><span class="glyphicon glyphicon-edit"></span> Edit Jaksa</h4>
	      </div>

		<form class="form-horizontal" action="jaksa_action/update.php" method="POST" id="updateJaksaForm">

	      <div class="modal-body">

<div class="edit-messages"></div>

			  <div class="form-group"> <!--/here teh addclass has-error will appear -->
			    <label for="editNip" class="col-sm-3 control-label">NIP</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editNip" name="editNip" placeholder="NIP">
				<!-- here the text will apper  -->
			    </div>
			  </div>

				<div class="form-group">
			    <label for="editNama" class="col-sm-3 control-label">Nama</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editNama" name="editNama" placeholder="Nama">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editNrp" class="col-sm-3 control-label">NRP</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editNrp" name="editNrp" placeholder="NRP">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editKarpeg" class="col-sm-3 control-label">Karpeg</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editKarpeg" name="editKarpeg" placeholder="Karpeg">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editTtl" class="col-sm-3 control-label">TTL</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editTtl" name="editTtl" placeholder="TTL">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editAgama" class="col-sm-3 control-label">Agama</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editAgama" name="editAgama" placeholder="Agama">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editJk" class="col-sm-3 control-label">Jenis Kelamin</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editJk" name="editJk" placeholder="Jenis Kelamin">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editStatus_nikah" class="col-sm-3 control-label">Status Nikah</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editStatus_nikah" name="editStatus_nikah" placeholder="Status Nikah">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editJum_anak" class="col-sm-3 control-label">Jumlah Anak</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editJum_anak" name="editJum_anak" placeholder="Jumlah Anak">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editAlamat" class="col-sm-3 control-label">Alamat</label>
			    <div class="col-sm-9">
			    	<textarea class="form-control" id="editAlamat" name="editAlamat" rows="3" placeholder="Alamat"></textarea>
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editHp" class="col-sm-3 control-label">No. HP</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editHp" name="editHp" placeholder="Nomor Handphone">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editPendidikan" class="col-sm-3 control-label">Pendidikan</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editPendidikan" name="editPendidikan" placeholder="Pendidikan">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editGolru" class="col-sm-3 control-label">Golongan</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editGolru" name="editGolru" placeholder="Golongan">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editPangkat" class="col-sm-3 control-label">Pangkat</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editPangkat" name="editPangkat" placeholder="Pangkat">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editStruktural" class="col-sm-3 control-label">Struktural</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editStruktural" name="editStruktural" placeholder="Struktural">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editFungsional" class="col-sm-3 control-label">Fungsional</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editFungsional" name="editFungsional" placeholder="Fungsional">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editTmt_jaksa" class="col-sm-3 control-label">Tamat Jaksa</label>
			    <div class="col-sm-9">
			      <input type="text" class="form-control" id="editTmt_jaksa" name="editTmt_jaksa" placeholder="Tamat Jaksa">
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editPassword" class="col-sm-3 control-label">Password</label>
			    <div class="col-sm-9">
			      <textarea class="form-control" id="editPassword" name="editPassword" rows="3" placeholder="Password"></textarea>
			    </div>
			  </div>

			  <div class="form-group">
			    <label for="editFoto" class="col-sm-3 control-label">Foto</label>
			    <div class="col-sm-9">
			    	<textarea class="form-control" id="editFoto" name="editFoto" rows="3" placeholder="Foto"></textarea>
			    </div>
			  </div>

	      </div>



	      <div class="modal-footer editJaksaModal">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-primary">Save changes</button>
	      </div>

	      </form>
	    </div><!-- /.modal-content -->
	  </div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- /edit modal -->

	<!-- jquery plugin -->
	<script type="text/javascript" src="assests/jquery/jquery.min.js"></script>
	<!-- bootstrap js -->
	<script type="text/javascript" src="assests/bootstrap/js/bootstrap.min.js"></script>
	<!-- datatables js -->
	<script type="text/javascript" src="assests/datatables/datatables.min.js"></script>
	<!-- include custom index.js -->
	<script type="text/javascript" src="custom/js/indexjaksa.js"></script>
	<!-- <script type="text/javascript" src="assests/js/jquery-2.1.3.min.js"></script> -->
  <!-- <script type="text/javascript" src="assests/js/bootstrap.min.js"></script> -->
  <!-- <script type="text/javascript" src="assests/js/jquery.dataTables.min.js"></script> -->
  <!-- <script type="text/javascript" src="assests/js/dataTables.bootstrap.js"></script> -->
	<script type="text/javascript" src="assests/js/bootstrap-select.min.js"></script>
  <script type="text/javascript" src="assests/js/main.js"></script>
  <script type="text/javascript" src="assests/js/index.js"></script>

</body>
</html>
