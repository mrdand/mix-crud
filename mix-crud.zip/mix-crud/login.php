<?php
    ob_start();
    session_start();
    require_once 'dbconnect.php';

    // it will never let you open index(login) page if session is set
    if ( isset($_SESSION['user'])!="" ) {
        header("Location: index.php");
        exit;
    }

    $error = false;

    if( isset($_POST['btn-login']) ) {

        // prevent sql injections/ clear user invalid inputs
        $email = trim($_POST['email']);
        $email = strip_tags($email);
        $email = htmlspecialchars($email);

        $pass = trim($_POST['pass']);
        $pass = strip_tags($pass);
        $pass = htmlspecialchars($pass);
        // prevent sql injections / clear user invalid inputs

        if(empty($email)){
            $error = true;
            $emailError = "Please enter your email address.";
        } else if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
            $error = true;
            $emailError = "Please enter valid email address.";
        }

        if(empty($pass)){
            $error = true;
            $passError = "Please enter your password.";
        }

        // if there's no error, continue to login
        if (!$error) {

            $password = hash('sha256', $pass); // password hashing using SHA256

            $res=mysql_query("SELECT id, username, password FROM tb_user WHERE email='$email'");
            $row=mysql_fetch_array($res);
            $count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row

            if( $count == 1 && $row['password']==$password ) {
                $_SESSION['user'] = $row['id'];
                header("Location: index.php");
            } else {
                $errMSG = "Incorrect Credentials, Try again...";
            }

        }

    }
?>


<!DOCTYPE html>
<html>

<head>
    <title>CRUD</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" type="text/css" href="assests/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assests/css/animate.css">
    <link rel="stylesheet" type="text/css" href="assests/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assests/css/login.css">
    <link rel="stylesheet" type="text/css" href="assests/css/theme.css">

    <script type="text/javascript" src="assests/js/jquery-2.1.3.min.js"></script>
    <script type="text/javascript" src="assests/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container">
        <div class="login-box">
        <div id="login-form">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">

        <div class="col-md-12">

            <div class="form-group">
                <h3 class="">Admin</h3>
            </div>

            <hr>



            <?php
            if ( isset($errMSG) ) {

                ?>
                <div class="form-group">
                <div class="alert alert-danger">
                <span class="fa fa-info"></span> <?php echo $errMSG; ?>
                </div>
                </div>
                <?php
            }
            ?>

            <div class="box">

            <div class="form-group">
                <div class="control">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo $email; ?>" maxlength="40" />
                </div>
                <span class="text-danger"><?php echo $emailError; ?></span>
            </div>

            <div class="form-group">
                <div class="control">
                    <label>Password</label>
                <input type="password" name="pass" class="form-control" maxlength="15" />
                </div>
                <span class="text-danger"><?php echo $passError; ?></span>
            </div>

<!--             <div class="form-group">
                <hr />
            </div>
             -->
            <div class="form-group">
                <button type="submit" class="btn btn-block btn-lg btn-primary" name="btn-login">Sign In</button>
            </div>

        </div>

<!--             <div class="info-box">
                   <span class="text-left"><a href="register.html">Create new account</a></span>
                   <span class="text-right"><a href="#">Forgot password?</a></span>
                   <div class="clear-both"></div>
                </div> -->

        </div>

    </form>
    </div>
</div>
    </div>
    <!-- <script type="text/javascript">
        $(function() {
            $("#login-form").submit(function() {
                $("#login-progress").removeClass("hidden");

                setTimeout(function(){
                    $("#login-progress").addClass("hidden");
                    $("#login-message").removeClass("hidden");
                    setTimeout(function(){
                        window.location.assign("index.html")
                    },1000);
                },1000);
                return false;
            });
        });
    </script> -->
</body>

</html>
<?php ob_end_flush(); ?>
