-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 20, 2017 at 06:42 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xcloudsy_berkas`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_jaksa`
--

CREATE TABLE `tb_jaksa` (
  `id` int(11) NOT NULL,
  `nip` varchar(18) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `nrp` varchar(10) NOT NULL,
  `karpeg` varchar(10) NOT NULL,
  `ttl` varchar(50) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `jk` varchar(10) NOT NULL,
  `status_nikah` varchar(20) NOT NULL,
  `jum_anak` int(2) NOT NULL,
  `alamat` text NOT NULL,
  `hp` varchar(15) NOT NULL,
  `pendidikan` varchar(150) NOT NULL,
  `golru` varchar(10) NOT NULL,
  `pangkat` varchar(50) NOT NULL,
  `struktural` varchar(100) NOT NULL,
  `fungsional` varchar(50) NOT NULL,
  `tmt_jaksa` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `foto` text NOT NULL,
  `token` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_jaksa`
--

INSERT INTO `tb_jaksa` (`id`, `nip`, `nama`, `nrp`, `karpeg`, `ttl`, `agama`, `jk`, `status_nikah`, `jum_anak`, `alamat`, `hp`, `pendidikan`, `golru`, `pangkat`, `struktural`, `fungsional`, `tmt_jaksa`, `password`, `foto`, `token`) VALUES
(24, '214123', 'Lala', '-', '-', '-', 'Islam', '-', '-', 0, '', '', '', '', '', '', '', '', '', '', ''),
(23, '214123', 'Lala', '-', '-', '-', 'Islam', '-', '-', 0, '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(2) NOT NULL,
  `username` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `email`, `password`, `nama_lengkap`) VALUES
(1, 'pidsus', 'admin@admin.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Operator Pidsus'),
(2, 'admin', 'admin@mail.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_jaksa`
--
ALTER TABLE `tb_jaksa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_jaksa`
--
ALTER TABLE `tb_jaksa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
